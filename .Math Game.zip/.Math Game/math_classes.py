import random
import base64
import json
import time

class MathOperations: ## Arathmetic functions
    def multiplacation(x1,x2): # Multiplication
        value = int(x1*x2)
        return value
    def divission(X,random_x1,random_x2): # Divission
        is_float = True
        while is_float:
            value = random.randint(random_x1,random_x2)            
            if X % value == 0:
                return value
    def addition(x1,x2): # Addition
        value = int(x1+x2)
        return value
    def subtraction(x1,x2): # Subtraction
        value = int(x1-x2)
        return value
    
class FileData(): # A class reading, encrypting, updating, and decrypting complied as base64 data.

    def Encrypt():

        f = open("scores.mg", "r") ## opening decrypted file.
        s = f.read()
        f.close()

        s = str.encode(s) # formatting for data storage
        en_f = base64.standard_b64encode(s)
        en_s = bytes.decode(en_f)

        file = open("scores.mg", "w") # storing data 
        file.write(en_s)

    def Decrypt(modes,difficulty,rounds,score): # Decrypting
        
        f = open("scores.mg", "r") ## opening encrypted file.
        s = f.read()
        f.close()

        s = str.encode(s) # formatting for data storage
        en_f = base64.standard_b64decode(s)
        en_b = bytes.decode(en_f)

        data = json.JSONDecoder().decode(en_b) # attempting to decode json formatted data and create a mutable dictonary.

        ## data = json.dumps(data) # attempt to create mutable dictionary.

        ## del data["score"][f"{modes}"][f"{difficulty}"][f"{rounds}"] # refrencing data in mg file
        ## data["score"][f"{modes}"][f"{difficulty}"][f"{rounds}"] = score # !! Gives an error 'cannot convert immutable object.'

        data = str(data)

        #print(dict["score"][f"{modes}"][f"{difficulty}"])

        file = open("scores.mg", "w") # storing data 
        file.write(data)
    

    def StampTime(): # printing start time.
        start = time.time()
        return start

    def Score(start,rounds): # determining score as average time pased answering questions.
        finish = time.time() # final time as decimal
        score = (finish - start) / rounds # taking the average
        return score
    
    ##def ScoreCheck(modes,difficulty,rounds,dict,score): ## !! UNFINISHED NO UNCOMMENT 
        
     
FileData.Encrypt() ##  UNCOMMENT TO TEST
#FileData.Decrypt("a","weak",10,1) ##  UNCOMMENT TO TEST

